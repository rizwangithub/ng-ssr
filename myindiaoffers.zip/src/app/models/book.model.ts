export interface Book{
    name: string;
    isbn: string;
    authors: string[];
    publisher: string[];
    country: string;
    mediaType: string;
    released: string;
}