
import { Component, OnInit  } from '@angular/core';
import { Router } from '@angular/router';

@Component({
    selector: 'app-download',
    templateUrl: './download-app.component.html',

})
export class DownloadappComponent {
    constructor(public router: Router) {
    }
}
